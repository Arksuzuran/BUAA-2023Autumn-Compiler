package ir.types;

/**
 * @Description Value的基本类型
 * @Author
 * @Date 2023/10/31
 **/
public class ValueType {
    public int getSize(){
        return 0;
    }
    public boolean isI1(){
        return false;
    }
}
