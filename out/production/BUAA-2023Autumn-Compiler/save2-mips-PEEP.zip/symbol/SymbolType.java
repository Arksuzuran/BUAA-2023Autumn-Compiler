package symbol;

public enum SymbolType {
    Var,        // 变量或者函数参数
    Const,      // 常量
    Function,   // 函数
}
